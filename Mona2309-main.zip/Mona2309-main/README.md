

**Languages**: Python, SQL,Powershell, Unix

**Framework:** Flask

**Libraries & Tools**:Lambda Functions, NumPy, Pandas, Scikit-Learn, SciPy, Matplotlib

**Data Analysis**: Exploratory Data Analysis


******HAPPY LEARNING******
